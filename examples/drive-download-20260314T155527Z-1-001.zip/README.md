
# AI Release Guardian

AI Release Guardian — прототип нейро-сотрудника для анализа веб-интерфейсов
и выявления рисков изменений между релизами.

Система анализирует DOM-структуру веб-страницы, декомпозирует интерфейс
на тестируемые объекты и использует LLM для генерации тестов и анализа рисков.

---

## Возможности системы

AI Release Guardian помогает QA-инженеру автоматически:

- анализировать структуру интерфейса веб-страницы
- выделять testable objects
- группировать элементы по типам
- генерировать тестовые сценарии
- анализировать UX и функциональные риски
- выполнять UI diff между версиями страницы
- оценивать release risk
- сохранять историю запусков анализа

---

## Архитектура системы

DOM analysis (Selenium + BeautifulSoup)

↓

Testable objects extraction

↓

Representative elements selection

↓

RAG retrieval (knowledge base)

↓

LLM reasoning

↓

Test generation (rule-based + LLM)

↓

Page summary generation

↓

Site-level UI checks

↓

Visual consistency checks

↓

Page risk analysis

↓

Run artifacts storage

↓

UI diff analysis

↓

AI diff interpretation

↓

Release risk score

---

## Используемые технологии

- Python
- Selenium
- BeautifulSoup
- LlamaIndex
- Sentence Transformers
- HuggingFace embeddings
- Русскоязычная LLM (локальная)
- VSEGPT API

---

## RAG и снижение галлюцинаций

В проекте используются техники повышения качества RAG:

- Query enrichment (расширение запросов)
- DOM-grounded retrieval
- Фильтрация контекста
- Representative elements
- Структурированные testable objects
- Run-based анализ интерфейса
- Разделение rule-based и AI-генерации

---

## Структура run

Sites/
  site_name/
    runs/
      run_001/
      run_002/

---

## Последний запуск

Site: trainer_sedtest-tools_ru

Run: run_009

Total testable objects: 6

Artifacts directory:
/content/drive/MyDrive/AI_Release_Guardian_MVP/Sites/trainer_sedtest-tools_ru/runs/run_009

